package com.rigor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class IndexController {

	  @RequestMapping(value = "/product", method = RequestMethod.GET)
	    public String getIndexPage() {
	        return "create-product";
	    }
	  
	  @RequestMapping(value = "/search", method = RequestMethod.GET)
		public ModelAndView searchPage(){
		   ModelAndView mav = new ModelAndView("list-product");
		   return mav;
		}
}